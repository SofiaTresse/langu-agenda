@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
 echo Instale o Node.js versao 22.13 ou superior antes de abrir a agenda.
 pause
 exit /b 1
)
echo Abra http://localhost:3000 no seu navegador.
echo Mantenha esta janela aberta enquanto usar a agenda.
node server.mjs
pause
