import test from 'node:test';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {mkdtemp,rm} from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
test('Solicitação, acesso protegido, conflitos, aprovação, recusa e bloqueio',async()=>{
const dir=await mkdtemp(path.join(os.tmpdir(),'langu-test-'));const port=33000+Math.floor(Math.random()*10000);
const proc=spawn(process.execPath,['server.mjs'],{cwd:path.dirname(fileURLToPath(import.meta.url)),env:{...process.env,PORT:String(port),DB_PATH:path.join(dir,'test.sqlite'),APP_URL:'https://agenda.exemplo.test',WHATSAPP_WEBHOOK_URL:''},stdio:['ignore','pipe','pipe']});
try{
await new Promise((resolve,reject)=>{const timeout=setTimeout(()=>reject(Error('Servidor não iniciou')),10000);proc.stdout.once('data',()=>{clearTimeout(timeout);resolve()});proc.once('error',reject)});
let cookie='';async function call(route,body,auth=false){const r=await fetch(`http://127.0.0.1:${port}/api/${route}`,{method:body===undefined?'GET':'POST',headers:{...(body===undefined?{}:{'Content-Type':'application/json'}),...(auth?{Cookie:cookie}:{})},body:body===undefined?undefined:JSON.stringify(body)});return {status:r.status,data:await r.json(),cookie:r.headers.get('set-cookie')}}
assert.equal((await call('admin/requests')).status,401);
assert.equal((await call('setup',{password:'short'})).status,400);
assert.equal((await call('setup',{password:'test-password-123'})).status,200);
assert.equal((await call('setup',{password:'test-password-456'})).status,409);
assert.equal((await call('login',{password:'wrong'})).status,401);
cookie=(await call('login',{password:'test-password-123'})).cookie.split(';')[0];assert.ok(cookie);
const d=new Date();d.setUTCDate(d.getUTCDate()+2);while([0,6].includes(d.getUTCDay()))d.setUTCDate(d.getUTCDate()+1);const date=d.toISOString().slice(0,10);
const slots=(await call('slots?date='+date)).data.slots;assert.ok(slots.length>1);
const payload={name:'Pessoa de teste',phone:'5511999999999',date,time:slots[0]};
assert.equal((await call('request',{...payload,phone:'errado'})).status,400);
const first=await call('request',payload);assert.equal(first.status,201);
assert.equal((await call('request',payload)).status,400);
assert.ok(!(await call('slots?date='+date)).data.slots.includes(slots[0]));
assert.equal((await call('admin/decision',{id:first.data.id,status:'accepted'})).status,401);
const accept=await call('admin/decision',{id:first.data.id,status:'accepted'},true);assert.equal(accept.status,200);assert.match(accept.data.message,/confirmada/);assert.equal(accept.data.delivery,'manual');
assert.equal((await call('admin/decision',{id:first.data.id,status:'rejected'},true)).status,409);
const second=await call('request',{...payload,time:slots[1]});assert.equal(second.status,201);
const reject=await call('admin/decision',{id:second.data.id,status:'rejected',reason:'Equipe indisponível.'},true);assert.equal(reject.status,200);assert.match(reject.data.message,/https:\/\/agenda.exemplo.test/);assert.match(reject.data.message,/Equipe indisponível/);
assert.ok((await call('slots?date='+date)).data.slots.includes(slots[1]));
assert.equal((await call('admin/block',{date,time:slots[1]},true)).status,200);
assert.ok(!(await call('slots?date='+date)).data.slots.includes(slots[1]));
assert.equal((await call('admin/block',{date,time:slots[1],remove:true},true)).status,200);
assert.ok((await call('slots?date='+date)).data.slots.includes(slots[1]));
assert.equal((await call('admin/requests',undefined,true)).data.requests.length,2);
assert.equal((await call('admin/hours',{hours:['09:00','09:10']},true)).status,400);
await call('admin/logout',{},true);assert.equal((await call('admin/requests',undefined,true)).status,401);
const cross=await fetch(`http://127.0.0.1:${port}/api/login`,{method:'POST',headers:{Origin:'https://outro.test','Content-Type':'application/json'},body:'{}'});assert.equal(cross.status,403);
}finally{proc.kill();await new Promise(r=>proc.once('exit',r));await rm(dir,{recursive:true,force:true})}
});
